create view itemuser as
  select `mvc_test`.`tab_rating`.`userID`  AS `userID`,
         `mvc_test`.`tab_rating`.`movieID` AS `movieID`,
         `mvc_test`.`tab_rating`.`rating`  AS `rating`
  from `mvc_test`.`tab_rating`;

